#lang pollen

◊(define-meta title            "Part I: This World")

◊center{
    ◊p{◊i{
        "Be patient, for the world is broad and wide."
        }}
    ◊p{
        ◊hyperlink["01-chapter.html"]{ → }
    }
}
