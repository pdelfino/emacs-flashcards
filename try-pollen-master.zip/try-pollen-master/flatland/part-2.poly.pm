#lang pollen

◊(define-meta title            "Part II: Other Worlds")

◊verse[#:italic #t]{                       "O brave new worlds,
That have such people in them!"}

◊center{
    ◊p{
        ◊hyperlink["13-chapter.html"]{ → }
    }
}
