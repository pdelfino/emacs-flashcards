#lang pollen

◊(define-meta title "$title$")
◊(define-meta doc-publish-date "$date$")
$if(tags)$◊(define-meta tags "$tags$")$endif$

$body$
