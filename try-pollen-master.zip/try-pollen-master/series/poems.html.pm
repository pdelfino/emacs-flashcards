#lang pollen

◊(define-meta title "Poems")
◊(define-meta author "Joel Dueck")
◊(define-meta summary "Hail poetry, divine emollient.")

◊p{Hail poetry, divine emollient.}
