#lang pollen

◊(define-meta title "Working Notebook")
◊(define-meta author "Joel Dueck")
◊(define-meta summary "Notes on why and how this site was made.")

◊p{Notes on why and how this site was made.}
