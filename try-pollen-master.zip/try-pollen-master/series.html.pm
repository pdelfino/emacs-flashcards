#lang pollen

◊(define-meta title "Series")
◊(define-meta author "Joel Dueck")

◊p{You just know everything's gonna be in a list somewhere.}
